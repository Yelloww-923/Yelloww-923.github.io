document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('myBtn').addEventListener('click', () => {
    window.location.href = 'https://heyzine.com/flip-book/314115b516.html';
  });
});
